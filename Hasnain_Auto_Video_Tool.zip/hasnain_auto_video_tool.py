
import os
from tkinter import filedialog, Tk, Label, Button, Checkbutton, IntVar
from moviepy.editor import *

# Create GUI first
root = Tk()
root.title("🎬 Hasnain Auto Video Tool")
root.geometry("500x400")

# Variables (after root initialized)
audio_path = ""
visual_folder = ""
music_path = ""
add_subtitles = IntVar()
add_animated_text = IntVar()
auto_music = IntVar()

# Select audio file
def select_audio():
    global audio_path
    audio_path = filedialog.askopenfilename(title="Select Audio File", filetypes=[("Audio Files", "*.mp3 *.wav")])
    Label(root, text="✔️ Audio Selected").pack()

# Select visual folder
def select_visuals():
    global visual_folder
    visual_folder = filedialog.askdirectory(title="Select Visuals Folder")
    Label(root, text="✔️ Visuals Folder Selected").pack()

# Select background music manually
def select_music():
    global music_path
    music_path = filedialog.askopenfilename(title="Select Background Music", filetypes=[("MP3 Files", "*.mp3")])
    Label(root, text="✔️ Music Selected").pack()

# Create final video
def create_video():
    if not audio_path or not visual_folder:
        Label(root, text="❌ Please select audio and visuals first!", fg="red").pack()
        return

    # Load audio
    narration = AudioFileClip(audio_path)

    # Load visuals
    visuals = []
    for file in os.listdir(visual_folder):
        filepath = os.path.join(visual_folder, file)
        if file.endswith(('.jpg', '.png')):
            clip = ImageClip(filepath).set_duration(5).resize(height=720)
            visuals.append(clip)
        elif file.endswith(('.mp4', '.mov')):
            clip = VideoFileClip(filepath).subclip(0, 5).resize(height=720)
            visuals.append(clip)

    if not visuals:
        Label(root, text="❌ No visuals found!", fg="red").pack()
        return

    # Concatenate visuals
    final_visual = concatenate_videoclips(visuals, method="compose")

    # Add animated text (if selected)
    if add_animated_text.get() == 1:
        txt_clip = TextClip("Never Give Up!", fontsize=70, color='white', font='Arial-Bold')
        txt_clip = txt_clip.set_duration(5).set_position('center').crossfadein(1)
        final_visual = CompositeVideoClip([final_visual, txt_clip.set_start(2)])

    # Set audio with/without background music
    final_audio = narration
    if auto_music.get() == 1 and not music_path:
        music_path = "default_music.mp3"  # Replace with your local auto music file path

    if music_path:
        bg_music = AudioFileClip(music_path).volumex(0.2)
        final_audio = CompositeAudioClip([narration, bg_music])

    final_video = final_visual.set_audio(final_audio)

    # Save video
    os.makedirs("output", exist_ok=True)
    output_path = os.path.join("output", "final_video.mp4")
    final_video.write_videofile(output_path, fps=24)
    Label(root, text=f"✅ Video Created: {output_path}", fg="blue").pack()

# GUI Buttons & Options
Label(root, text="🎤 Select Your Audio File", font=("Arial", 12)).pack(pady=5)
Button(root, text="Select Audio", command=select_audio).pack()

Label(root, text="🖼️ Select Visuals Folder", font=("Arial", 12)).pack(pady=5)
Button(root, text="Select Visuals", command=select_visuals).pack()

Checkbutton(root, text="Add Subtitles (Coming Soon)", variable=add_subtitles).pack()
Checkbutton(root, text="Add Animated Text", variable=add_animated_text).pack()
Checkbutton(root, text="Auto Background Music", variable=auto_music).pack()

Button(root, text="Select Custom Background Music", command=select_music).pack(pady=5)

Button(root, text="🚀 Create Final Video", font=("Arial", 14), bg="green", fg="white", command=create_video).pack(pady=20)

root.mainloop()
